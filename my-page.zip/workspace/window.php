<!DOCTYPE html>
    <html>
        <head>
            <link href="style.css" type="text/css" rel="stylesheet" />
        </head>
        <body>
            <div class="footer">
                <a href="logout.php">Logout</a>
            </div>
        </body>
    </html>