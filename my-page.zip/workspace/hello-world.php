<html><body>
<?php
// A simple web site in Cloud9 that runs through Apache
// Press the 'Run' button on the top to start the web server,
// then click the URL that is emitted to the Output tab of the console

echo 'Hello world from Cloud9!';
//Link to Instagram

//Facebook profile pic
?>
<br/>
<img src="http://graph.facebook.com/100000872443978/picture?width=250&height=250" alt = "My Profile Picture"
            title = "Jenna Cray's Profile Picture" height = "250" width = "250" border = "1"/>
<?php
//Last Facebook status
?>

<br/>
<img src="https://scontent-sjc2-1.cdninstagram.com/t51.2885-19/s150x150/13166848_1100446836678783_1707978383_a.jpg" alt = "Insta Prof Pic"
            title = "Jenna Cray's Insta Photo" height = "250" width = "250" border = "2"/>
<br/>
<img src="https://media.licdn.com/mpr/mpr/shrinknp_400_400/p/7/005/08f/368/257a3f8.jpg" alt = "LinkedIn"
            title = "Jenna Cray's LinkedIn Prof Pic" height = "250" width="250" border = "3" />

</body>
</html>